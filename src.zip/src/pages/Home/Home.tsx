// Home.tsx

import { useItems } from '@/features/items/hooks/useItems'
import { useReserveItem } from '@/features/items/hooks/useReserveItem'
import ItemCard from '@/features/items/components/ItemCard'

export default function Home() {
  const { items } = useItems()
  const { handleReserve } = useReserveItem()

  return (
    <div>
      {items.map((item) => (
        <ItemCard
          key={item.id}
          item={item}
          onReserve={() => {
            // aquí abres modal (no directo)
            console.log('abrir modal', item.id)
          }}
        />
      ))}
    </div>
  )
}