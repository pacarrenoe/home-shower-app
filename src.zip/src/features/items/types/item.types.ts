// item.types.ts
export interface ItemOption {
  store: string
  price: number
  url?: string
}

export interface Item {
  id: string
  name: string
  image: string
  description: string
  status: 'wanted' | 'owned'
  options: ItemOption[]

  // NUEVO
  reserved?: boolean
  reservedBy?: string
  reservedOption?: ItemOption
}