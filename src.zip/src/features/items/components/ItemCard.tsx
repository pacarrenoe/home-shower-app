// src/features/items/components/ItemCard.tsx

import styles from './ItemCard.module.css'
import type { Item } from '../types/item.types'

interface Props {
  item: Item
  onReserve: () => void
}

export default function ItemCard({ item, onReserve }: Props) {
  const isReserved = item.reserved

  return (
    <div className={`${styles.card} ${isReserved ? styles.reserved : ''}`}>
      <img src={item.image} alt={item.name} />

      <h3>{item.name}</h3>
      <p>{item.description}</p>

      {isReserved ? (
        <p className={styles.reservedText}>
          Reservado por {item.reservedBy}
        </p>
      ) : (
        <button onClick={onReserve}>
          Yo te lo regalaré
        </button>
      )}
    </div>
  )
}