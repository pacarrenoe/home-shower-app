// src/features/items/services/item.service.ts

import { doc, runTransaction, collection, addDoc, serverTimestamp } from 'firebase/firestore'
import { db } from '@/app/firebase'
import { ItemOption } from '../types/item.types'

interface ReserveItemParams {
  itemId: string
  name: string
  option: ItemOption
}

export const reserveItem = async ({ itemId, name, option }: ReserveItemParams) => {
  const itemRef = doc(db, 'items', itemId)

  await runTransaction(db, async (transaction) => {
    const itemSnap = await transaction.get(itemRef)

    if (!itemSnap.exists()) throw new Error('Item no existe')

    const itemData = itemSnap.data()

    if (itemData.reserved) {
      throw new Error('Este item ya fue reservado')
    }

    // 1. actualizar estado real
    transaction.update(itemRef, {
      reserved: true,
      reservedBy: name,
      reservedOption: option,
    })

    // 2. guardar histórico
    const reservationsRef = collection(db, 'reservations')

    await addDoc(reservationsRef, {
      itemId,
      itemName: itemData.name,
      name,
      option,
      createdAt: serverTimestamp(),
    })
  })
}