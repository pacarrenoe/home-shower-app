// src/features/items/hooks/useReserveItem.ts

import { useState } from 'react'
import { reserveItem } from '../services/item.service'
import type { ItemOption } from '../types/item.types'

export const useReserveItem = () => {
  const [loading, setLoading] = useState(false)

  const handleReserve = async (
    itemId: string,
    name: string,
    option: ItemOption
  ) => {
    setLoading(true)
    try {
      await reserveItem({ itemId, name, option })
    } finally {
      setLoading(false)
    }
  }

  return { handleReserve, loading }
}